package Queue;

public class Node<T> {
	T Data;
	Node next;
}

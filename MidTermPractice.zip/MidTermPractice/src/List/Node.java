package List;

public class Node<T> {
	T Data;
	Node next;
	
	Node(T Entry) {
		this.Data=Entry;
	}
}

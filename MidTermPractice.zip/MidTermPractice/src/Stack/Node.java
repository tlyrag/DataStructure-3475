package Stack;

public class Node <T>{
	T data;
	Node next;
	
	Node(T entry) {
		this.data = entry;
	}
	
}
